
var id='';

$(function() {
    $('#click_btn_rr').click(function() {
		checkCurrentTab('insta_remove'); 
	});
});

$(function() {
    $('#get_all_links').click(function() {
		checkCurrentTab('get_all_links'); 
	});
});



function checkCurrentTab(val_place) {
    chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
		chrome.tabs.sendMessage(tabs[0].id, val_place, null, function(obj) {});
    });
}



document.addEventListener('DOMContentLoaded', function () {
    chrome.windows.getCurrent(function (currentWindow) {
        chrome.tabs.query({active: true, windowId: currentWindow.id}, function(activeTabs) {
            // inject content_script to current tab
            chrome.tabs.executeScript(activeTabs[0].id, {file: 'content_script.js', allFrames: false});
        });
    });
});





