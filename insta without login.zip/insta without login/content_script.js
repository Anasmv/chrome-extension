// you will see this log in console log of current tab in Chrome when the script is injected
console.log("content_script.js");

 

	
	
 
   



chrome.runtime.onMessage.addListener(function(cmd, sender, sendResponse) {
	
	//alert('working ');
	
	
	
	
	var str 		=	cmd;
	//alert(str);
	var res 		=	str.split("==");
	var type 		=	res[0];
	var value 		=	res[1];
	var val_text 	=	res[2];
	
	
	
	//alert('type == '+type+'   \n ---- value == '+value+ '\n ---- ' +val_text);
	
	
	
	function removeElementsByClass(className){
		var elements = document.getElementsByClassName(className);
		while(elements.length > 0){
			elements[0].parentNode.removeChild(elements[0]);
		}
	}
	
	

	
	if(str == 'get_all_links')
	{
		
		var links_val = '';
		var links = document.getElementsByTagName('a');
		//alert(links.length);
        for(var i = 0; i< links.length; i++){
			links_val +=  '<br>'+links[i].href;
			//document.getElementById('links_href').innerHTML = links_val;
			//alert(links);
        }
		alert(links_val);
		
		//document.getElementById('links_href').innerHTML = links_val;
		
		var div=document.createElement("div"); 
		document.querySelector('#links_href').appendChild(div);
		
		html1 = links_val;
		div.innerHTML=html1;
	}
	
	
	if(str == 'insta_remove')
	{
		removeElementsByClass("RnEpo");
		
		
		body = document.getElementsByTagName('body')[0];
		body.style.overflow = '';
		
		
		var div=document.createElement("div"); 
		document.querySelector('.SCxLW').appendChild(div);
		
		html = "<div id='links_href'></div>";
		div.innerHTML=html;
    }
	
	
	
	
    
});